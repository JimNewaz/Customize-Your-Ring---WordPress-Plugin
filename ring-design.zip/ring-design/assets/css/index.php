<?php 
    die('You can not be here');
?>